package com.example.hackerplayer

import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.OutputStreamWriter
import java.util.Locale

private data class PlayerTheme(
    var name: String = "Hacker CRT",
    var background: Int = Color.rgb(5, 8, 5),
    var surface: Int = Color.rgb(16, 23, 16),
    var surfaceAlt: Int = Color.rgb(23, 33, 23),
    var primary: Int = Color.rgb(57, 255, 20),
    var secondary: Int = Color.rgb(0, 217, 255),
    var textPrimary: Int = Color.rgb(232, 255, 229),
    var textSecondary: Int = Color.rgb(145, 168, 142),
    var border: Int = Color.rgb(49, 90, 49),
    var danger: Int = Color.rgb(255, 67, 93),
    var success: Int = Color.rgb(57, 255, 20),
    var videoBackground: Int = Color.BLACK,
    var playerControls: Int = Color.rgb(57, 255, 20),
    var progressTrack: Int = Color.rgb(56, 82, 56),
    var progressFill: Int = Color.rgb(57, 255, 20),
    var buffer: Int = Color.rgb(139, 207, 131),
    var timeText: Int = Color.rgb(232, 255, 229),
    var buttonBackground: Int = Color.rgb(20, 32, 20),
    var buttonText: Int = Color.rgb(57, 255, 20),
    var buttonPressedBackground: Int = Color.rgb(35, 69, 35),
    var buttonBorder: Int = Color.rgb(49, 90, 49),
    var buttonBorderWidthDp: Float = 1f,
    var buttonRadiusDp: Float = 16f,
    var buttonHeightDp: Float = 48f,
    var buttonTextSizeSp: Float = 12f,
    var buttonAllCaps: Boolean = false,
    var panelBackground: Int = Color.argb(230, 16, 23, 16),
    var panelBorder: Int = Color.argb(128, 57, 255, 20),
    var panelBorderWidthDp: Float = 1f,
    var panelRadiusDp: Float = 20f,
    var panelPaddingDp: Float = 16f,
    var fontFamily: String = "monospace",
    var titleSizeSp: Float = 24f,
    var bodySizeSp: Float = 14f,
    var secondarySizeSp: Float = 12f,
    var letterSpacing: Float = 0.08f,
    var titleStyle: String = "bold",
    var pagePaddingDp: Float = 14f,
    var itemSpacingDp: Float = 7f,
    var playerCornerRadiusDp: Float = 14f,
    var compactMode: Boolean = false,
    var glow: Boolean = true,
    var glowAlpha: Float = 0.55f,
    var scanlines: Boolean = false,
    var scanlineAlpha: Float = 0.12f,
    var vignette: Boolean = false,
    var animations: Boolean = true,
    var appTitle: String = "HACKER PLAYER",
    var openVideo: String = "ОТКРЫТЬ ИЗ DOWNLOADS",
    var importTheme: String = "ИМПОРТ XML / JSON",
    var exportTheme: String = "ЭКСПОРТ XML",
    var openSubtitles: String = "СУБТИТРЫ SRT",
    var settings: String = "НАСТРОЙКИ ПЛЕЕРА",
    var resetTheme: String = "СБРОСИТЬ ТЕМУ",
    var idleMessage: String = "Открой видео из Download или памяти телефона"
)

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var root: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private var theme = PlayerTheme()
    private var currentVideoUri: Uri? = null
    private var currentSubtitleUri: Uri? = null
    private var playbackSpeed = 1f
    private var repeatMode = Player.REPEAT_MODE_OFF
    private var resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
    private var volume = 1f
    private var keepScreenOn = false
    private var screenBrightness = -1f

    private val openVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            currentSubtitleUri = null
            currentVideoUri = uri
            playCurrentMedia()
        }
    }
    private val openTheme = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importTheme(uri)
    }
    private val exportTheme = registerForActivityResult(ActivityResultContracts.CreateDocument("application/xml")) { uri ->
        if (uri != null) exportThemeTo(uri)
    }
    private val openSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            currentSubtitleUri = uri
            if (currentVideoUri != null) {
                val oldPosition = player?.currentPosition ?: 0L
                val wasPlaying = player?.isPlaying ?: true
                playCurrentMedia()
                player?.seekTo(oldPosition)
                player?.playWhenReady = wasPlaying
                Toast.makeText(this, "Субтитры добавлены", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Сначала открой видео, затем выбери SRT-субтитры", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("hacker_player", MODE_PRIVATE)
        loadPlayerSettings()
        val savedXml = prefs.getString("theme_xml", null)
        if (!savedXml.isNullOrBlank()) {
            try { theme = parseXmlTheme(savedXml) } catch (_: Exception) { theme = PlayerTheme() }
        }
        buildUi()
        applyPlayerSettings()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun rounded(bg: Int, border: Int, borderWidthDp: Float, radiusDp: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(bg)
            cornerRadius = dp(radiusDp).toFloat()
            if (borderWidthDp > 0f) setStroke(dp(borderWidthDp), border)
        }

    private fun typeface(): Typeface = when (theme.fontFamily.lowercase(Locale.ROOT)) {
        "sans", "sans-serif" -> Typeface.create("sans-serif", Typeface.NORMAL)
        "serif" -> Typeface.create("serif", Typeface.NORMAL)
        "default" -> Typeface.DEFAULT
        else -> Typeface.create("monospace", Typeface.NORMAL)
    }

    private fun buildUi() {
        val t = theme
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(t.pagePaddingDp))
            setBackgroundColor(t.background)
        }
        val title = TextView(this).apply {
            text = t.appTitle
            textSize = t.titleSizeSp
            setTextColor(t.primary)
            gravity = Gravity.CENTER
            typeface = if (t.titleStyle.equals("normal", true)) typeface() else Typeface.create(typeface(), Typeface.BOLD)
            letterSpacing = t.letterSpacing
            setPadding(dp(8f), dp(5f), dp(8f), dp(7f))
            if (t.glow && t.glowAlpha > 0f) setShadowLayer(dp(10f).toFloat(), 0f, 0f, withAlpha(t.primary, t.glowAlpha))
        }
        status = TextView(this).apply {
            text = t.idleMessage
            textSize = t.secondarySizeSp
            setTextColor(t.textSecondary)
            gravity = Gravity.CENTER
            setPadding(dp(t.panelPaddingDp / 2f), dp(5f), dp(t.panelPaddingDp / 2f), dp(5f))
            background = rounded(t.panelBackground, t.panelBorder, t.panelBorderWidthDp, t.panelRadiusDp)
            typeface = typeface()
        }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackground(rounded(t.videoBackground, t.border, t.panelBorderWidthDp, t.playerCornerRadiusDp))
            clipToOutline = true
            setResizeMode(this@MainActivity.resizeMode)
            player = this@MainActivity.player
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(t.itemSpacingDp) })
        val playerFrame = FrameLayout(this)
        playerFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        playerFrame.addView(EffectsOverlay(), FrameLayout.LayoutParams(-1, -1))
        root.addView(playerFrame, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(t.itemSpacingDp / 2f)
            bottomMargin = dp(t.itemSpacingDp)
        })
        addActionRow(root,
            makeButton(t.openVideo) { openVideo.launch(arrayOf("video/*")) },
            makeButton(t.importTheme) { openTheme.launch(arrayOf("application/xml", "text/xml", "application/json", "text/*", "*/*")) })
        addActionRow(root,
            makeButton(t.exportTheme) { exportTheme.launch("${safeFileName(theme.name)}.xml") },
            makeButton(t.openSubtitles) { openSubtitle.launch(arrayOf("application/x-subrip", "text/*", "application/octet-stream", "*/*")) })
        addActionRow(root,
            makeButton(t.settings) { showPlayerSettings() },
            makeButton(t.resetTheme) {
                theme = PlayerTheme()
                prefs.edit().remove("theme_xml").apply()
                buildUi()
                Toast.makeText(this, "Стандартная тема восстановлена", Toast.LENGTH_SHORT).show()
            })
        setContentView(root)
        tintPlayerControls(playerView, t)
        playerView.player = player
        playerView.setResizeMode(resizeMode)
        applyPlayerSettings()
    }

    private fun addActionRow(parent: LinearLayout, left: Button, right: Button) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val spacing = dp(if (theme.compactMode) theme.itemSpacingDp / 2f else theme.itemSpacingDp)
        row.addView(left, LinearLayout.LayoutParams(0, dp(theme.buttonHeightDp), 1f).apply { marginEnd = spacing / 2 })
        row.addView(right, LinearLayout.LayoutParams(0, dp(theme.buttonHeightDp), 1f).apply { marginStart = spacing / 2 })
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(theme.itemSpacingDp / 2f) })
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = theme.buttonTextSizeSp
        setTextColor(theme.buttonText)
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), rounded(theme.buttonPressedBackground, theme.buttonBorder, theme.buttonBorderWidthDp, theme.buttonRadiusDp))
            addState(intArrayOf(), rounded(theme.buttonBackground, theme.buttonBorder, theme.buttonBorderWidthDp, theme.buttonRadiusDp))
        }
        isAllCaps = theme.buttonAllCaps
        typeface = typeface()
        minHeight = dp(theme.buttonHeightDp)
        setPadding(dp(5f), dp(4f), dp(5f), dp(4f))
        stateListAnimator = null
        setOnClickListener {
            if (theme.animations) animate().alpha(0.86f).setDuration(65).withEndAction { animate().alpha(1f).setDuration(90).start() }.start()
            action()
        }
    }

    private inner class EffectsOverlay : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        init { isClickable = false; isFocusable = false; setWillNotDraw(false) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (theme.scanlines) {
                paint.shader = null
                paint.color = withAlpha(Color.BLACK, theme.scanlineAlpha)
                paint.strokeWidth = dp(1f).toFloat()
                var y = 0f; val step = dp(4f).toFloat().coerceAtLeast(2f)
                while (y < h) { canvas.drawLine(0f, y, w, y, paint); y += step }
            }
            if (theme.vignette && w > 0f && h > 0f) {
                paint.style = Paint.Style.FILL
                paint.shader = RadialGradient(w / 2f, h / 2f, maxOf(w, h) * 0.72f,
                    intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)), floatArrayOf(0.45f, 1f), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint); paint.shader = null
            }
        }
    }

    private fun playCurrentMedia() {
        val uri = currentVideoUri ?: return
        try {
            if (player == null) player = ExoPlayer.Builder(this).build()
            playerView.player = player
            val itemBuilder = MediaItem.Builder().setUri(uri)
            currentSubtitleUri?.let { subtitle ->
                val config = MediaItem.SubtitleConfiguration.Builder(subtitle)
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage("und")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                itemBuilder.setSubtitleConfigurations(listOf(config))
            }
            player?.setMediaItem(itemBuilder.build())
            player?.prepare()
            player?.playWhenReady = true
            player?.volume = volume
            player?.repeatMode = repeatMode
            player?.playbackParameters = PlaybackParameters(playbackSpeed)
            status.text = queryDisplayName(uri) ?: (uri.lastPathSegment ?: "Воспроизведение видео")
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть видео: ${e.localizedMessage ?: "неподдерживаемый файл"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun showPlayerSettings() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(8f), dp(20f), dp(4f))
        }
        val scroll = android.widget.ScrollView(this).apply { addView(content) }
        val speeds = listOf("0,5×", "0,75×", "1× (обычно)", "1,25×", "1,5×", "1,75×", "2×")
        val speedValues = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
        val repeatLabels = listOf("Повтор выключен", "Повторять текущее видео")
        val repeatValues = listOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ONE)
        val resizeLabels = listOf("Вписать целиком", "Заполнить экран", "Увеличить с обрезкой")
        val resizeValues = listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)
        val volumeLabels = listOf("25%", "50%", "75%", "100%")
        val volumeValues = listOf(0.25f, 0.5f, 0.75f, 1f)
        val brightnessLabels = listOf("Как в системе", "Низкая", "Средняя", "Высокая")
        val brightnessValues = listOf(-1f, 0.25f, 0.6f, 1f)
        val speedSpinner = addSettingSpinner(content, "Скорость воспроизведения", speeds, speedValues.indexOfFirst { it == playbackSpeed }.coerceAtLeast(0))
        val repeatSpinner = addSettingSpinner(content, "Повтор", repeatLabels, repeatValues.indexOf(repeatMode).coerceAtLeast(0))
        val resizeSpinner = addSettingSpinner(content, "Масштаб видео", resizeLabels, resizeValues.indexOf(resizeMode).coerceAtLeast(0))
        val volumeSpinner = addSettingSpinner(content, "Громкость плеера", volumeLabels, volumeValues.indexOfFirst { it == volume }.coerceAtLeast(0))
        val brightnessSpinner = addSettingSpinner(content, "Яркость экрана", brightnessLabels, brightnessValues.indexOfFirst { it == screenBrightness }.coerceAtLeast(0))
        val keepScreenCheck = CheckBox(this).apply { text = "Не выключать экран во время видео"; isChecked = keepScreenOn; setTextColor(theme.textPrimary) }
        content.addView(keepScreenCheck)
        AlertDialog.Builder(this)
            .setTitle("Настройки видеоплеера")
            .setView(scroll)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                playbackSpeed = speedValues[speedSpinner.selectedItemPosition]
                repeatMode = repeatValues[repeatSpinner.selectedItemPosition]
                resizeMode = resizeValues[resizeSpinner.selectedItemPosition]
                volume = volumeValues[volumeSpinner.selectedItemPosition]
                screenBrightness = brightnessValues[brightnessSpinner.selectedItemPosition]
                keepScreenOn = keepScreenCheck.isChecked
                savePlayerSettings()
                applyPlayerSettings()
                Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun addSettingSpinner(parent: LinearLayout, label: String, values: List<String>, selected: Int): Spinner {
        val tv = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(theme.textPrimary); setPadding(0, dp(10f), 0, dp(3f))
        }
        parent.addView(tv)
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        spinner.setSelection(selected)
        parent.addView(spinner, LinearLayout.LayoutParams(-1, -2))
        return spinner
    }

    private fun loadPlayerSettings() {
        playbackSpeed = prefs.getFloat("speed", 1f)
        repeatMode = prefs.getInt("repeat", Player.REPEAT_MODE_OFF)
        resizeMode = prefs.getInt("resize", AspectRatioFrameLayout.RESIZE_MODE_FIT)
        volume = prefs.getFloat("volume", 1f)
        screenBrightness = prefs.getFloat("brightness", -1f)
        keepScreenOn = prefs.getBoolean("keep_screen_on", false)
    }

    private fun savePlayerSettings() {
        prefs.edit()
            .putFloat("speed", playbackSpeed).putInt("repeat", repeatMode)
            .putInt("resize", resizeMode).putFloat("volume", volume)
            .putFloat("brightness", screenBrightness).putBoolean("keep_screen_on", keepScreenOn).apply()
    }

    private fun applyPlayerSettings() {
        if (::playerView.isInitialized) playerView.setResizeMode(resizeMode)
        player?.volume = volume
        player?.repeatMode = repeatMode
        player?.playbackParameters = PlaybackParameters(playbackSpeed)
        if (keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.screenBrightness = screenBrightness
        window.attributes = lp
    }

    private fun importTheme(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalArgumentException("Не удалось прочитать файл")
            val parsed = when {
                text.trimStart().startsWith("{") -> parseJsonTheme(text)
                text.trimStart().startsWith("<") -> parseXmlTheme(text)
                else -> throw IllegalArgumentException("Ожидается XML или JSON")
            }
            theme = parsed
            prefs.edit().putString("theme_xml", serializeThemeXml(theme)).apply()
            buildUi()
            status.text = "Тема применена: ${theme.name}"
            Toast.makeText(this, "Тема «${theme.name}» импортирована", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка темы: ${e.message ?: "неверный файл"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportThemeTo(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { out -> OutputStreamWriter(out, Charsets.UTF_8).use { it.write(serializeThemeXml(theme)) } }
                ?: throw IllegalArgumentException("Не удалось сохранить файл")
            Toast.makeText(this, "XML-тема экспортирована", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка экспорта: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseJsonTheme(text: String): PlayerTheme {
        val obj = JSONObject(text)
        val t = PlayerTheme()
        t.name = obj.optString("name", t.name)
        t.primary = color(obj.optString("accent", "#39FF14"))
        t.background = color(obj.optString("background", "#050805"))
        t.surface = color(obj.optString("panel", "#121912"))
        t.buttonBackground = t.surface
        t.buttonText = t.primary
        t.panelBackground = t.surface
        return t
    }

    /** App-specific theme XML only; arbitrary Android layout XML is not executed or inflated. */
    private fun parseXmlTheme(text: String): PlayerTheme {
        val t = PlayerTheme()
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(text.reader())
        var event = parser.eventType
        var foundRoot = false
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "theme" -> { foundRoot = true; t.name = parser.getAttributeValue(null, "name") ?: t.name }
                    "colors" -> {
                        t.background = attrColor(parser, "background", t.background)
                        t.surface = attrColor(parser, "surface", t.surface)
                        t.surfaceAlt = attrColor(parser, "surfaceAlt", t.surfaceAlt)
                        t.primary = attrColor(parser, "primary", t.primary)
                        t.secondary = attrColor(parser, "secondary", t.secondary)
                        t.textPrimary = attrColor(parser, "textPrimary", t.textPrimary)
                        t.textSecondary = attrColor(parser, "textSecondary", t.textSecondary)
                        t.border = attrColor(parser, "border", t.border)
                        t.danger = attrColor(parser, "danger", t.danger)
                        t.success = attrColor(parser, "success", t.success)
                        t.buttonBackground = t.surface; t.buttonPressedBackground = t.surfaceAlt
                        t.buttonBorder = t.border; t.buttonText = t.primary; t.timeText = t.textPrimary
                    }
                    "player" -> {
                        t.videoBackground = attrColor(parser, "videoBackground", t.videoBackground)
                        t.playerControls = attrColor(parser, "controls", t.playerControls)
                        t.progressTrack = attrColor(parser, "progressTrack", t.progressTrack)
                        t.progressFill = attrColor(parser, "progressFill", t.progressFill)
                        t.buffer = attrColor(parser, "buffer", t.buffer)
                        t.timeText = attrColor(parser, "timeText", t.timeText)
                    }
                    "buttons" -> {
                        t.buttonBackground = attrColor(parser, "background", t.buttonBackground)
                        t.buttonText = attrColor(parser, "text", t.buttonText)
                        t.buttonPressedBackground = attrColor(parser, "pressedBackground", t.buttonPressedBackground)
                        t.buttonBorder = attrColor(parser, "border", t.buttonBorder)
                        t.buttonBorderWidthDp = attrFloat(parser, "borderWidthDp", t.buttonBorderWidthDp, 0f, 10f)
                        t.buttonRadiusDp = attrFloat(parser, "radiusDp", t.buttonRadiusDp, 0f, 100f)
                        t.buttonHeightDp = attrFloat(parser, "heightDp", t.buttonHeightDp, 32f, 100f)
                        t.buttonTextSizeSp = attrFloat(parser, "textSizeSp", t.buttonTextSizeSp, 8f, 32f)
                        t.buttonAllCaps = attrBool(parser, "allCaps", t.buttonAllCaps)
                    }
                    "panels" -> {
                        t.panelBackground = attrColor(parser, "background", t.panelBackground)
                        t.panelBorder = attrColor(parser, "border", t.panelBorder)
                        t.panelBorderWidthDp = attrFloat(parser, "borderWidthDp", t.panelBorderWidthDp, 0f, 10f)
                        t.panelRadiusDp = attrFloat(parser, "radiusDp", t.panelRadiusDp, 0f, 100f)
                        t.panelPaddingDp = attrFloat(parser, "paddingDp", t.panelPaddingDp, 0f, 64f)
                    }
                    "typography" -> {
                        t.fontFamily = parser.getAttributeValue(null, "fontFamily") ?: t.fontFamily
                        t.titleSizeSp = attrFloat(parser, "titleSizeSp", t.titleSizeSp, 10f, 48f)
                        t.bodySizeSp = attrFloat(parser, "bodySizeSp", t.bodySizeSp, 8f, 30f)
                        t.secondarySizeSp = attrFloat(parser, "secondarySizeSp", t.secondarySizeSp, 8f, 24f)
                        t.letterSpacing = attrFloat(parser, "letterSpacing", t.letterSpacing, 0f, 0.3f)
                        t.titleStyle = parser.getAttributeValue(null, "titleStyle") ?: t.titleStyle
                    }
                    "layout" -> {
                        t.pagePaddingDp = attrFloat(parser, "pagePaddingDp", t.pagePaddingDp, 0f, 48f)
                        t.itemSpacingDp = attrFloat(parser, "itemSpacingDp", t.itemSpacingDp, 0f, 32f)
                        t.playerCornerRadiusDp = attrFloat(parser, "playerCornerRadiusDp", t.playerCornerRadiusDp, 0f, 64f)
                        t.compactMode = attrBool(parser, "compactMode", t.compactMode)
                    }
                    "effects" -> {
                        t.glow = attrBool(parser, "glow", t.glow)
                        t.glowAlpha = attrFloat(parser, "glowAlpha", t.glowAlpha, 0f, 1f)
                        t.scanlines = attrBool(parser, "scanlines", t.scanlines)
                        t.scanlineAlpha = attrFloat(parser, "scanlineAlpha", t.scanlineAlpha, 0f, 1f)
                        t.vignette = attrBool(parser, "vignette", t.vignette)
                        t.animations = attrBool(parser, "animations", t.animations)
                    }
                    "labels" -> {
                        t.appTitle = parser.getAttributeValue(null, "appTitle") ?: t.appTitle
                        t.openVideo = parser.getAttributeValue(null, "openVideo") ?: t.openVideo
                        t.importTheme = parser.getAttributeValue(null, "importTheme") ?: t.importTheme
                        t.exportTheme = parser.getAttributeValue(null, "exportTheme") ?: t.exportTheme
                        t.openSubtitles = parser.getAttributeValue(null, "openSubtitles") ?: t.openSubtitles
                        t.settings = parser.getAttributeValue(null, "settings") ?: t.settings
                        t.resetTheme = parser.getAttributeValue(null, "resetTheme") ?: t.resetTheme
                        t.idleMessage = parser.getAttributeValue(null, "idleMessage") ?: t.idleMessage
                    }
                }
            }
            event = parser.next()
        }
        if (!foundRoot) throw IllegalArgumentException("Не найден корневой тег <theme>")
        return t
    }

    private fun serializeThemeXml(t: PlayerTheme): String = buildString {
        appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
        appendLine("<!-- Hacker Player theme schema v1. Import this into Hacker Player. -->")
        appendLine("<theme version=\"1\" name=\"${xml(t.name)}\">")
        appendLine("  <colors background=\"${hex(t.background)}\" surface=\"${hex(t.surface)}\" surfaceAlt=\"${hex(t.surfaceAlt)}\" primary=\"${hex(t.primary)}\" secondary=\"${hex(t.secondary)}\" textPrimary=\"${hex(t.textPrimary)}\" textSecondary=\"${hex(t.textSecondary)}\" border=\"${hex(t.border)}\" danger=\"${hex(t.danger)}\" success=\"${hex(t.success)}\" />")
        appendLine("  <player videoBackground=\"${hex(t.videoBackground)}\" controls=\"${hex(t.playerControls)}\" progressTrack=\"${hex(t.progressTrack)}\" progressFill=\"${hex(t.progressFill)}\" buffer=\"${hex(t.buffer)}\" timeText=\"${hex(t.timeText)}\" />")
        appendLine("  <buttons background=\"${hex(t.buttonBackground)}\" text=\"${hex(t.buttonText)}\" pressedBackground=\"${hex(t.buttonPressedBackground)}\" border=\"${hex(t.buttonBorder)}\" borderWidthDp=\"${t.buttonBorderWidthDp}\" radiusDp=\"${t.buttonRadiusDp}\" heightDp=\"${t.buttonHeightDp}\" textSizeSp=\"${t.buttonTextSizeSp}\" allCaps=\"${t.buttonAllCaps}\" />")
        appendLine("  <panels background=\"${hex(t.panelBackground)}\" border=\"${hex(t.panelBorder)}\" borderWidthDp=\"${t.panelBorderWidthDp}\" radiusDp=\"${t.panelRadiusDp}\" paddingDp=\"${t.panelPaddingDp}\" />")
        appendLine("  <typography fontFamily=\"${xml(t.fontFamily)}\" titleSizeSp=\"${t.titleSizeSp}\" bodySizeSp=\"${t.bodySizeSp}\" secondarySizeSp=\"${t.secondarySizeSp}\" letterSpacing=\"${t.letterSpacing}\" titleStyle=\"${xml(t.titleStyle)}\" />")
        appendLine("  <layout pagePaddingDp=\"${t.pagePaddingDp}\" itemSpacingDp=\"${t.itemSpacingDp}\" playerCornerRadiusDp=\"${t.playerCornerRadiusDp}\" compactMode=\"${t.compactMode}\" />")
        appendLine("  <effects glow=\"${t.glow}\" glowAlpha=\"${t.glowAlpha}\" scanlines=\"${t.scanlines}\" scanlineAlpha=\"${t.scanlineAlpha}\" vignette=\"${t.vignette}\" animations=\"${t.animations}\" />")
        appendLine("  <labels appTitle=\"${xml(t.appTitle)}\" openVideo=\"${xml(t.openVideo)}\" importTheme=\"${xml(t.importTheme)}\" exportTheme=\"${xml(t.exportTheme)}\" openSubtitles=\"${xml(t.openSubtitles)}\" settings=\"${xml(t.settings)}\" resetTheme=\"${xml(t.resetTheme)}\" idleMessage=\"${xml(t.idleMessage)}\" />")
        appendLine("</theme>")
    }

    private fun hex(color: Int): String = String.format(Locale.US, "#%08X", color)
    private fun xml(value: String): String = value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    private fun safeFileName(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifBlank { "HackerPlayerTheme" }
    private fun attrColor(parser: org.xmlpull.v1.XmlPullParser, name: String, fallback: Int): Int = parser.getAttributeValue(null, name)?.let { color(it) } ?: fallback
    private fun attrFloat(parser: org.xmlpull.v1.XmlPullParser, name: String, fallback: Float, min: Float, max: Float): Float {
        val raw = parser.getAttributeValue(null, name) ?: return fallback
        val value = raw.toFloatOrNull() ?: throw IllegalArgumentException("$name должен быть числом")
        if (value < min || value > max) throw IllegalArgumentException("$name должен быть в диапазоне $min–$max")
        return value
    }
    private fun attrBool(parser: org.xmlpull.v1.XmlPullParser, name: String, fallback: Boolean): Boolean {
        val raw = parser.getAttributeValue(null, name) ?: return fallback
        if (raw.equals("true", true)) return true
        if (raw.equals("false", true)) return false
        throw IllegalArgumentException("$name должен быть true или false")
    }
    private fun color(value: String): Int = try { Color.parseColor(value) } catch (_: Exception) { throw IllegalArgumentException("Неверный цвет: $value") }
    private fun withAlpha(color: Int, alpha: Float): Int = Color.argb((alpha.coerceIn(0f, 1f) * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    private fun tintPlayerControls(view: View, t: PlayerTheme) {
        when (view) {
            is ImageView -> view.setColorFilter(t.playerControls)
            is SeekBar -> {
                view.progressTintList = ColorStateList.valueOf(t.progressFill)
                view.progressBackgroundTintList = ColorStateList.valueOf(t.progressTrack)
                view.thumbTintList = ColorStateList.valueOf(t.playerControls)
            }
            is ProgressBar -> { view.progressTintList = ColorStateList.valueOf(t.progressFill); view.indeterminateTintList = ColorStateList.valueOf(t.buffer) }
            is TextView -> view.setTextColor(t.timeText)
        }
        if (view is ViewGroup) for (i in 0 until view.childCount) tintPlayerControls(view.getChildAt(i), t)
    }

    override fun onStart() {
        super.onStart()
        if (player == null) player = ExoPlayer.Builder(this).build()
        if (::playerView.isInitialized) playerView.player = player
        applyPlayerSettings()
    }

    override fun onStop() {
        super.onStop()
        player?.release(); player = null
    }
}
