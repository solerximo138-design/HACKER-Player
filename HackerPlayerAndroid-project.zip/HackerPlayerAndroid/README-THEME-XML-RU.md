# Формат XML-тем Hacker Player

Файл темы можно импортировать прямо в Hacker Player. Изменяйте цвета, кнопки, панели, размеры и шрифт, затем сохраняйте файл с расширением `.xml` и выбирайте **ИМПОРТ XML / JSON**.

Поддерживаемые разделы:

- `<colors>` — фон приложения, поверхности, основной/вторичный акцент, текст, рамки, ошибки и успех.
- `<player>` — фон видеополя, цвет контролов, полоса перемотки и индикатор буферизации.
- `<buttons>` — цвет кнопок, цвет текста, pressed-состояние, рамка, скругление, высота и размер текста.
- `<panels>` — цвет и прозрачность панелей, рамка, радиус скругления, внутренний отступ.
- `<typography>` — моноширинный / sans-serif / serif шрифт, размеры текста и межбуквенный интервал.
- `<layout>` — отступы, расстояние между элементами, скругление плеера и компактный режим.
- `<effects>` — свечение заголовка, CRT scanlines, виньетка и анимации кнопок.
- `<labels>` — названия и тексты кнопок.

Цвета записываются как `#RRGGBB` или `#AARRGGBB`; в формате с восемью знаками первые две цифры — альфа-канал (прозрачность). Размеры измеряются в `dp` или `sp`; альфа и glow используют значения `0.0`–`1.0`.

Пример:

```xml
<?xml version="1.0" encoding="utf-8"?>
<theme version="1" name="Blue Glass">
    <colors background="#FF050812" surface="#CC101D32" surfaceAlt="#FF172B48"
        primary="#FF00D9FF" secondary="#FFFFD84D" textPrimary="#FFFFFFFF"
        textSecondary="#FF9FB7CC" border="#8000D9FF" danger="#FFFF435D"
        success="#FF66FF99" />
    <player videoBackground="#FF000000" controls="#FF00D9FF"
        progressTrack="#FF29435F" progressFill="#FF00D9FF"
        buffer="#FF8BCFEE" timeText="#FFFFFFFF" />
    <buttons background="#CC101D32" text="#FF00D9FF"
        pressedBackground="#FF172B48" border="#8000D9FF"
        borderWidthDp="1" radiusDp="22" heightDp="48"
        textSizeSp="12" allCaps="false" />
    <panels background="#CC101D32" border="#8000D9FF"
        borderWidthDp="1" radiusDp="24" paddingDp="16" />
    <typography fontFamily="sans-serif" titleSizeSp="24" bodySizeSp="14"
        secondarySizeSp="12" letterSpacing="0.02" titleStyle="bold" />
    <layout pagePaddingDp="16" itemSpacingDp="8"
        playerCornerRadiusDp="20" compactMode="false" />
    <effects glow="true" glowAlpha="0.35" scanlines="false"
        scanlineAlpha="0.12" vignette="false" animations="true" />
    <labels appTitle="BLUE GLASS PLAYER"
        openVideo="OPEN VIDEO / DOWNLOADS" importTheme="IMPORT XML / JSON"
        exportTheme="EXPORT XML" openSubtitles="SUBTITLES SRT"
        settings="PLAYER SETTINGS" resetTheme="RESET THEME"
        idleMessage="Choose a video to begin" />
</theme>
```

**Важно:** это XML-схема темы, которую понимает Hacker Player, а не универсальный импорт Android `styles.xml`/layout XML от любых приложений. Импортируемая тема меняет только поддерживаемые параметры оформления; она не запускает произвольный код.
