# Hacker Player — Android video player starter

Native Android video player project using AndroidX Media3 ExoPlayer.

## Features in this project
- Opens local video using Android's system document picker; choose **Downloads/Download** in the picker to select downloaded video.
- Media3 playback controls and device-supported media formats.
- Import custom Hacker Player themes from XML or basic JSON.
- Export the current full supported theme as XML.
- Subtitle attachment picker for SubRip `.srt` files.
- Player settings: speed (0.5x–2x), repeat mode, resize mode (fit/fill/zoom), volume, screen brightness, keep screen on.
- Persists theme and player settings.
- Example full XML theme is in `themes/hacker-crt-full.xml`.

## Build a debug APK
Requirements: Android Studio, JDK 17, Android SDK Platform 35, Gradle 8.9 (the GitHub workflow configures these tools in cloud build).

### Cloud build with GitHub Actions
1. Create a repository on GitHub and upload every project file, including `.github/workflows/build-apk.yml`.
2. Open the repository's Actions tab and allow GitHub Actions if prompted.
3. Run **Build Hacker Player APK**, or push the project to `main`/`master`.
4. When the workflow succeeds, download the `HackerPlayer-debug-APK` artifact and extract `app-debug.apk`.

### Android Studio
Open this project, sync Gradle, then run `assembleDebug` or use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This environment doesn't include Android SDK or Gradle and has no access to download build dependencies, so an APK was **not built in this session**. The project source is provided for building and testing. Verify behavior on the target Android device before relying on it; format support depends on Android codecs and the media library.

## Theme XML limitation
The XML importer handles the documented Hacker Player schema. It does not execute or universally import arbitrary XML layout/resource files from other Android apps.
